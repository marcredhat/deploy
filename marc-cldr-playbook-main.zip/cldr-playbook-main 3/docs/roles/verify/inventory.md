# Inventory Verification

This role asserts basic expectations on the format of the inventory in isolation of the cluster definitions.

Examples include:
- Ensure that each group has at least 1 host

This will allow us to make basic assumptions on the inventory's format.
